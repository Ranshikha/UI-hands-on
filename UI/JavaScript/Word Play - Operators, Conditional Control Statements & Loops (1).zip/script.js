function wordPlay(number)
{
    var i=1;
    var res=" ";
    
    if(number>50)
    {
        return "Range is High";
    }
    else if(number<1) 
    {
        return "Not Valid";
    }
    else if(number>=1 && number <=50)
    {
        
        while(i<=number)
        {
            if(i%3===0 && i%5===0)
            {
              res+="Jump ";
            }
            else if(i%3===0)
            {
                    res+="Tap ";
                
            }
            else if(i%5===0)
            {
                    res+="Clap ";
            }
            else
            {
                res+=i+" ";
            }
            i++;
        }
        res=res.substring(0,res.length-1);
        return res;
    }
}