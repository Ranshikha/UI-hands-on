function modifyString(str) {
    str=str.split(' ').join('');
    var nstr=str.toLowerCase();
   return nstr;
}

function uniqueCharacters(str)
{
   str= modifyString(str);
   var st=new Set();
   var uniql="";
   for(var i=0;i<str.length;i++)
   {
       if(st.has(str[i])){
           continue;
       }
       else{
           uniql+=str[i];
           st.add(str[i]);
       }
       
   }
   return uniql;
}
