function OrderCake(str) {
    
    var m = str.length;
    var weight=str[0]+str[1]+str[2]+str[3];
    var ordernumber=str[m-3]+str[m-2]+str[m-1];
    var cakename=str.substring(4,m-3)
    var price=""
    price+=Math.round((weight/1000)*450);
    
    var ans="Your order for "+Math.round(weight/1000)+" kg "+cakename+" cake has been taken. You are requested to pay Rs. "+price+" on the order no "+ordernumber;
	return ans;//fill the code
}

