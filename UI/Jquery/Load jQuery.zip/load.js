//WRITE YOUR jQUERY CODE HERE
var msg="jQuery is loaded!!!";
$('#msg').html(msg);