//Write Your jQuery Code Here
$('#btnId').click(function(){
    var msg='<b>"Welcome '+$('#txt').val()+'!"</b>';
    $('#address').html(msg);
});