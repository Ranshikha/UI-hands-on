// WRITE YOUR CODE HERE
$("p").css("color","orange");
$("p:nth-child(2)").css("fontSize","50%");
$("#icecreamfloats li").css("background","orange");
$(".flavours li").css("background","lightblue");
$(".flavours").css("fontSize","120%");