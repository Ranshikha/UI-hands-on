//WRITE YOUR jQUERY CODE HRE



$("#btn-id").click(function(){
$.ajax({
url: "employee.json",
dataType: "text",
error: function (request, error) {
$("#err-id").text("Error Message: Not found");
},
success: function () {
}
});
})