$("caption").css("background-color","lightblue");
$("tr:odd").css("background-color","lightblue");
$("tr:even").css("background-color","lightpink");