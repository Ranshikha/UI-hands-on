//WRITE YOUR jQUERY CODE HERE
$('#button1').click(function(){
    $("div[name$='Intelligence']").css("background","yellow");
});